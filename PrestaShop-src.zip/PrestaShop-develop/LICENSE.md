
Copyright (c) Since 2007 PrestaShop and Contributors.

PrestaShop Core is licensed under OSL-3.0 and PrestaShop Modules are licensed under AFL-3.0. Please read [/docs/licenses/LICENSE.txt](/docs/licenses/LICENSE.txt) for details.

You can find useful resources about open source and licenses files for librairies used in the PrestaShop project in [/docs/licenses/](/docs/licenses/)
